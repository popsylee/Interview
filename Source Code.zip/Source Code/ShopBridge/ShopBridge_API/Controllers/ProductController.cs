﻿using ShopBridge_API.Attributes;
using ShopBridge_BLL.Contract;
using ShopBridge_CommonData.Constants;
using ShopBridge_CommonData.Extensions;
using ShopBridge_CommonData.Model.Product;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web.Http;

namespace ShopBridge_API.Controllers
{

    [ExceptionFilter]
    public class ProductController : ApiController
    {
        public IProductManager _IProductManager;
        public ProductController(IProductManager productManager)
        {
            this._IProductManager = productManager;
        }

        [HttpPost]
        [ValidationFilter]
        [Route("AddProduct")]
        public async Task<IHttpActionResult> AddItem(Product product)
        {
            var response = new ResponseBase();
            var responseData = await _IProductManager.AddItem(product);
            response.IsSuccess = responseData.Item1;
            response.Message = responseData.Item2 == null ? responseData.Item2 : responseData.Item2.ToUpper();

            return Ok(response);

        }
        [HttpPost]
        [ValidationFilter]
        [Route("ModifyProduct")]
        public async Task<IHttpActionResult> ModifyItem(Product product)
        {
            var response = new ResponseBase();
            var responseData = await _IProductManager.ModifyItem(product);
            response.IsSuccess = responseData.Item1;
            response.Message = responseData.Item2 == null ? responseData.Item2 : responseData.Item2.ToUpper();

            return Ok(response);

        }
        [HttpDelete]
        [Route("DeleteProduct")]
        public async Task<IHttpActionResult> DeleteItem(long ProductId)
        {
            var response = new ResponseBase();
            var responseData = await _IProductManager.DeleteItem(ProductId);
            response.IsSuccess = responseData.Item1;
            response.Message = responseData.Item2 == null ? responseData.Item2 : responseData.Item2.ToUpper();

            return Ok(response);

        }

        [HttpGet]
        [Route("ListProduct")]
        public async Task<IHttpActionResult> ListItems()
        {
            var response = new ResponseObject<List<Product>>();
            var responseData = await _IProductManager.ListItems();
            response.IsSuccess = responseData.Item1;
            response.Data = responseData.Item2;
            response.Message = responseData.Item2.Count == 0 ? ErrorMessage.NoRecordsFound : ErrorMessage.Success;

            return Ok(response);

        }
    }
}
