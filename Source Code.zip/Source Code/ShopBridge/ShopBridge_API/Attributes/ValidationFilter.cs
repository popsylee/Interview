﻿using Newtonsoft.Json;
using ShopBridge_CommonData.Constants;
using ShopBridge_CommonData.Extensions;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web;
using System.Web.Http.Controllers;
using System.Web.Http.Filters;
using System.Web.Http.ModelBinding;

namespace ShopBridge_API.Attributes
{
    public class ValidationFilter : ActionFilterAttribute
    {
        public override void OnActionExecuting(HttpActionContext actionContext)
        {
            bool IsValid = true;
            var response = new ResponseBase();
            if (!actionContext.ModelState.IsValid)
            {
                IsValid = false;
                response.Message = string.Join(" | ", actionContext.ModelState.Values.SelectMany(v => v.Errors).Select(e => e.ErrorMessage));
            }

            if (actionContext.Request.Method == HttpMethod.Post)
            {
                if (!IsValid)
                {
                    response.IsSuccess = false;
                    actionContext.Response = actionContext.Request.CreateResponse(HttpStatusCode.BadRequest, response);
                }
            }


        }
    }
}