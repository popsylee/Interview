﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ShopBridge_CommonData.Model.Product
{
    public class Product
    {

        public long ProductId { get; set; }
        [StringLength(50, ErrorMessage = "Please enter valid Product Code")]
        [RegularExpression("^[a-zA-Z0-9]*$", ErrorMessage = "Please enter valid Product Code.")]
        public string ProductCode { get; set; }

        [Required(ErrorMessage ="Please enter Product Name")]
        [StringLength(200,ErrorMessage ="Please enter valid Product Name")]
        [RegularExpression("^[ a-zA-Z]*$", ErrorMessage = "Please enter valid Product Name.")]
        public string ProductName { get; set; }

        [Required(ErrorMessage = "Please enter Product Description")]
        public string ProductDescription { get; set; }
        [Required(ErrorMessage = "Please enter Product Price")]
        [RegularExpression(@"[0-9]*\.?[0-9]+", ErrorMessage = "Product Price must be a Number only.")]
        [Range(typeof(Decimal), "0", "999999999", ErrorMessage = "Product Price must be a less than 10 digit.")]
        public Nullable<decimal> ProductPrice { get; set; }
        public Nullable<bool> IsActive { get; set; }
        public Nullable<System.DateTime> CreatedDate { get; set; }
        public Nullable<int> CreatedBy { get; set; }
        public Nullable<System.DateTime> ModifiedDate { get; set; }
        public Nullable<int> ModifiedBy { get; set; }

    }
}
