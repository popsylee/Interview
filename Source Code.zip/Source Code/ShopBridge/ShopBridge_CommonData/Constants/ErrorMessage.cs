﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ShopBridge_CommonData.Constants
{
    public class ErrorMessage
    {
        public const string InvalidProductId = "Invalid Product Id";
        public const string ProductCreatedSuccess = "Product Item Created Successfully";
        public const string ProductUpdatedSuccess = "Product Item Updated Successfully";
        public const string ProductCreationFailed = "Product Item Creation Failed";
        public const string ProductUpdationFailed = "Product Item Updation Failed";
        public const string ProductNameExists = "Product Name already exists";
        public const string ProductDeletedSuccess = "Product Item Deleted Successfully";
        public const string ProductDeletionFailed = "Product Item Deletion Failed";
        public const string NoRecordsFound = "No Records Found";
        public const string Success = "Success";

    }
}
