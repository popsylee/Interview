﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ShopBridge_CommonData.Extensions
{
    public class ResponseBase
    {
        private bool isSuccess;
        private string message;

        public ResponseBase()
        {
        }
      
        public bool IsSuccess
        {
            get { return isSuccess; }
            set { isSuccess = value; }
        }
     
        public string Message
        {
            get { return message; }
            set { message = value; }
        }
    }
    public class ResponseObject<T> : ResponseBase
    {
        public T Data { get; set; }
    }
    
  
}
