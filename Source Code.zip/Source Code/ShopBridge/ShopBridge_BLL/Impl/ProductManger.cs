﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ShopBridge_BLL.Contract;
using ShopBridge_CommonData.Constants;
using ShopBridge_CommonData.Model.Product;
using ShopBridge_DAL;

namespace ShopBridge_BLL.Impl
{
    public class ProductManger : IProductManager
    {

        public async Task<Tuple<bool, string>> AddItem(Product obj)
        {
            Tuple<bool, string> tuple = null;
            bool IsSuccess = false;
            int x = 0;
            try
            {
                using (var context = new AssignmentEntities())
                {
                    var data = context.ProductMasters.Where(u => u.ProductName == obj.ProductName.Trim()).SingleOrDefault();
                    if (data == null)
                    {
                        ProductMaster productMaster = new ProductMaster()
                        {
                            ProductName = obj.ProductName.Trim(),
                            ProductCode = DateTime.Now.ToString("ddMMHHyyyyhhmmss"),
                            ProductDescription = obj.ProductDescription.Trim(),
                            ProductPrice = obj.ProductPrice,
                            IsActive = true,
                            CreatedDate = DateTime.Now,
                            CreatedBy = obj.CreatedBy

                        };
                        context.ProductMasters.Add(productMaster);
                        x = await context.SaveChangesAsync();
                    }
                    else
                    {
                        return new Tuple<bool, string>(IsSuccess, ErrorMessage.ProductNameExists);
                    }

                }

                if (x > 0)
                {
                    IsSuccess = true;
                    tuple = new Tuple<bool, string>(IsSuccess, ErrorMessage.ProductCreatedSuccess);
                }
                else
                {
                    tuple = new Tuple<bool, string>(IsSuccess, ErrorMessage.ProductCreationFailed);
                }

            }
            catch (Exception)
            {
                throw;
            }

            return tuple;

        }

        public async Task<Tuple<bool, string>> ModifyItem(Product obj)
        {
            Tuple<bool, string> tuple = null;
            bool IsSuccess = false;
            int x = 0;
            try
            {

                using (var context = new AssignmentEntities())
                {

                    ProductMaster productMaster = context.ProductMasters.Where(u => u.ProductId == obj.ProductId).SingleOrDefault();
                    if (productMaster != null)
                    {
                        var data = context.ProductMasters.Where(u => u.ProductName == obj.ProductName.Trim() && u.ProductId != obj.ProductId).SingleOrDefault();
                        if (data == null)
                        {
                            productMaster.ProductName = obj.ProductName;
                            productMaster.ProductDescription = obj.ProductDescription;
                            productMaster.ProductPrice = obj.ProductPrice;
                            productMaster.ModifiedBy = obj.ModifiedBy;
                            productMaster.ModifiedDate = DateTime.Now;
                            productMaster.IsActive = obj.IsActive == null ? false : obj.IsActive;
                            context.Entry(productMaster).State = EntityState.Modified;
                            x = await context.SaveChangesAsync();
                        }
                        else
                        {
                            return new Tuple<bool, string>(IsSuccess, ErrorMessage.ProductNameExists);
                        }

                    }
                    else
                    {
                        return new Tuple<bool, string>(IsSuccess, ErrorMessage.InvalidProductId);
                    }
                }
                if (x > 0)
                {
                    IsSuccess = true;
                    tuple = new Tuple<bool, string>(IsSuccess, ErrorMessage.ProductUpdatedSuccess);
                }
                else
                {
                    tuple = new Tuple<bool, string>(IsSuccess, ErrorMessage.ProductUpdationFailed);
                }


            }
            catch (Exception)
            {
                throw;
            }

            return tuple;

        }

        public async Task<Tuple<bool, string>> DeleteItem(long ProductId)
        {
            Tuple<bool, string> tuple = null;
            bool IsSuccess = false;
            int x = 0;
            try
            {

                using (var context = new AssignmentEntities())
                {

                    ProductMaster productMaster = context.ProductMasters.Where(u => u.ProductId == ProductId).SingleOrDefault();
                    if (productMaster != null)
                    {
                        context.Entry(productMaster).State = EntityState.Deleted;
                        x = await context.SaveChangesAsync();
                    }
                    else
                    {
                        return new Tuple<bool, string>(IsSuccess, ErrorMessage.InvalidProductId);
                    }
                }
                if (x > 0)
                {
                    IsSuccess = true;
                    tuple = new Tuple<bool, string>(IsSuccess, ErrorMessage.ProductDeletedSuccess);
                }
                else
                {
                    tuple = new Tuple<bool, string>(IsSuccess, ErrorMessage.ProductDeletionFailed);
                }

            }
            catch (Exception)
            {
                throw;
            }

            return tuple;

        }

        public async Task<Tuple<bool, List<Product>>> ListItems()
        {
            Tuple<bool, List<Product>> tuple = null;
            bool IsSuccess = false;
            List<Product> lst = new List<Product>();
            try
            {

                using (var context = new AssignmentEntities())
                {
                    lst =  await(from pro in context.ProductMasters
                                               select new Product()
                                               {
                                                   ProductId = pro.ProductId,
                                                   ProductCode = pro.ProductCode,
                                                   ProductName = pro.ProductName,
                                                   ProductDescription = pro.ProductDescription,
                                                   ProductPrice = pro.ProductPrice,
                                                   CreatedBy = pro.CreatedBy,
                                                   CreatedDate = pro.CreatedDate,
                                                   ModifiedBy = pro.ModifiedBy,
                                                   ModifiedDate = pro.ModifiedDate,
                                                   IsActive = pro.IsActive
                                               }).ToListAsync();

                }
                if (lst.Count > 0)
                {
                    IsSuccess = true;
                    tuple = new Tuple<bool, List<Product>>(IsSuccess, lst);
                }
                else
                {
                    tuple = new Tuple<bool, List<Product>>(IsSuccess, lst);
                }

            }
            catch (Exception)
            {
                throw;
            }
            return tuple;

        }
      
    }
}
