﻿using ShopBridge_CommonData.Model.Product;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ShopBridge_BLL.Contract
{
    public interface IProductManager
    {
        Task<Tuple<bool, string>> AddItem(Product Product);
        Task<Tuple<bool, string>> ModifyItem(Product Product);

        Task<Tuple<bool, string>> DeleteItem(long ProductId);

        Task<Tuple<bool, List<Product>>> ListItems();
    }
}
